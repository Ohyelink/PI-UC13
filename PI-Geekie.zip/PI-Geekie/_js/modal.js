function abrirModal(){
    document.getElementById('modal').style.top="0";
    document.getElementById('modal').style.display="block";
}
function fecharModal(){
    document.getElementById('modal').style.top="-100%";
}